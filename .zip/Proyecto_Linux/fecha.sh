#!/bin/bash
ABREVIADA=`date +"%d/%m/%Y"`
echo -e "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "\e[33;3m   	   La fecha del dia de hoy es: $ABREVIADA \e[0m"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"