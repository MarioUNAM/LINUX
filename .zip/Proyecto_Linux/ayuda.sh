#!/bin/bash
#Imprime la ayuda para cada comando dentro de la shell

function arbol(){
  echo -e "\n*****************\tarbol\t****************"
	echo -e "Este comando sirve para mostrar graficamente los archivos que se encuentren dentro de la ruta especificada\n"
  echo -e "El comando acepta rutas relativas o absolutas"
  echo -e "Cuenta con 2 formas de usarse:"
  echo -e "Sin argumentos:\narbol \nMostrara el arbol de direcciones dentro de la carpeta que se ejecute el comando"
  echo -e "Con argumentos:\narbol direccion \nMostrara el arbol de direcciones del directorio que se pasa como argumento"
  echo -e "En caso de ingresar una direccion no valida o inexitente mostrara el mensaje \"NO EXISTE EL DIRECTORIO: direccion\""
  echo -e "Acepta nombre de carpetas con espacios"
}

function ayuda(){
  echo -e "\n*****************\tayuda\t****************"
	echo -e "Este comando muestra la descripcion de todos los comandos que se pueden utilizar dentro de la shell"
  echo -e "Cuenta con 2 formas de usarse:"
  echo -e "Sin argumentos:\nayuda \nMostrara la descripcion de todos los comandos"
  echo -e "Con argumentos:\nayuda comando \nMostrara la descripcion del comando especificado"
}

function fecha(){
  echo -e "\n*****************\tfecha\t****************"
	echo -e "Este comando mostrara la fecha actual"
  echo -e "No necesita ningun argumento solo se necesita escribir fecha para ejecutarlo"
}


function gato(){
  echo -e "\n*****************\tgato\t****************"
	echo -e "Este comando ejecuta el juego de gato"
  echo -e "Solo se introduce el comando gato no necesita de ningun argumento para ejecutarlo"
}

function hora(){
  echo -e "\n*****************\thora\t****************"
	echo -e "Este comando mostrara la hora exacta en que fue ejecutado"
  echo -e "No necesita ningun argumento solo se necesita escribir hora para ejecutarlo"
}

function infosis(){
  echo -e "\n*****************\tinfosis\t****************"
	echo -e "Muestra la informacion del sistema"
  echo -e "La forma de uso de este comando es solo escribir infosis en la terminal"
}


function buscar(){
  echo -e "\n*****************\tbuscar\t****************"
	echo -e "El comando buscar recibe 2 argumentos el primero es el nombre del archivo y el segundo el nombre de la carpeta"
  echo -e "Se necesita que los argumentos esten entre comillad como se muestra a continuación"
  echo -e "buscar \"nombre_archivo\" \"nombre_carpeta\""
  echo -e "Acepta nombres con espacios"
}


#####################PROGRAMA PRINCIPAL##########################################################

if [[ $1 == "" ]]
then 
  arbol
  ayuda
  fecha
  gato
  hora
  infosis
  buscar
else
	$1
fi

