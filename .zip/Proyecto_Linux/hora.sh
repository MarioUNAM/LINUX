#!/bin/bash
HORA=`date +"%r %p"`;
echo -e "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "\e[33;3m	  Son las $HORA\e[0m"; 
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"