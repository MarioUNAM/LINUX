#!/bin/bash
#Encontrar todos los archivos de audio 

buscamusica()
{
  flag=0
  for archivo in "$ubiact"/*; do
    if [[ -d "${archivo}" ]]
   	then
   		ubiact=${ubiact}/${archivo##*/}
        cd "$ubiact"
        buscamusica  
        cd ..
        ubiact=$(pwd)
    elif [ "${archivo##*.}" = "mp3" ] 
    then
      direcciones[$iteracion]="$archivo"
	  iteracion=$(($iteracion+1))
      flag=1
    fi
  done
  if [[ "$flag" -eq 1 ]]; then
     carpeta[iteracion_2]=$ubiact
     iteracion_2=$(($iteracion_2+1))
  fi
  flag=0
}

iteracion=0
iteracion_2=0
iteracion_3=0
ubiact="/home/$USER"
buscamusica 

while : 
do
	echo -e "$USER TIENES ARCHIVOS MP3 EN LAS SIGUIENTES CARPETAS\nELIJA UNA PARA REPRODUCIR"
	for (( i = 0; i < ${#carpeta[@]}; i++ )); do
		echo "$i.- ${carpeta[$i]##*mariohn/}"
	done
	echo "*.- Salir"
	read opdir
	if [[ "$opdir" == "*" ]]; then
		break
	elif [[ "$opdir" -ge "${#carpeta[@]}" ]]; then
		echo -e "Ingresa un valor valido"
	else
		IFS=''
		for (( i = 0; i < ${#direcciones[@]}; i++ )); do
			xdir=`dirname ${direcciones[$i]}`
			if [[ "$xdir" == "${carpeta[$opdir]}" ]]; then
				listamusic[iteracion_3]=${direcciones[$i]}
				iteracion_3=$(($iteracion_3+1))
			fi
		done

		while :
		do
			echo -e "Carpeta:${carpeta[opdir]}\nElija una opcion de reproduccion"
			for (( i = 0; i < ${#listamusic[@]}; i++ )); do
				echo "$i.- ${listamusic[$i]##*/}"
			done
			echo "? .- Reproducir todas"
			echo "* salir"
			read opsong
			if [[ "$opsong" == "*"  ]]; then
				break
			elif [[ "$opsong" == "?" ]]; then
				for song in ${listamusic[@]}; do
					mpg123 $song
				done
			else
				mpg123 ${listamusic[opsong]}
			fi

		done
		unset listamusic
		iteracion_3=0
	fi
done